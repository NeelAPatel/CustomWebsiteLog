A Pen created at CodePen.io. You can find this one at http://codepen.io/knolaust/pen/bNvZRQ.

 Experiment with material design. Animates the featured image and headline and adds button when hovered.